/* 
 * File:   main.cpp
 * Author: LUIS JAIME
 * Created on September 24, 04:36 PM
 * Purpose:  Creating a class template
 */

//System Libraries
#include <iostream>     //Input/Output Stream Library
#include<iomanip>
using namespace std;    //Standard Name-space under which System Libraries reside

//User Libraries

//Global Constants - Not variables only Math/Science/Conversion constants

//Function Prototypes

//Execution Begins Here!
int main() {
    //Declare Variables
 int hours;
 float grossPay, rate;
 rate=16.78;
    //Initialize Variables
 cout<<"Enter the amount of hours worked"<<endl;
 cout<<"Round to a whole number of hours"<<endl;
 cin>>hours;
 
    //Input Data/Variables
 
    //Process or map the inputs to the outputs
 if(hours>40)
     grossPay=rate*40+1.5*rate*(hours-40);
 else
     grossPay=rate*hours;   
 
 cout<<setprecision(2)<<fixed<<"Gross pay is $"<<grossPay<<endl;
    //Display/Output all pertinent variables
    
    //Exit the program
    return 0;
}